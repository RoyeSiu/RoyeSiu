// Ex.1
// function provided
//
// app.createChannel(channelName)
// create a new channel with a name
//
// app.clearChannelInput()
// clear the channel name input box

function handleNewChannelCreation(channelName) {

  if(channelName !== ""){
    app.createChannel(channelName);
    app.clearChannelInput();
  }
}
  // TODO
  // when a new channel is ready to be added, you need to do
  // 1. you should check if the channel name is empty string ""
  // 2. create the channel
  // 3. clear the input box



// Ex.2
// function provided
//
// app.createMessage(messageContent, messageTime, sentByMe)
// create and add a message to the current conversation box
//
// app.chatScrollToBottom()
// scroll to the bottom of current conversation box
//
// app.updateChannelList(messageChannel, messageContent, messageTime)
// update message and time on the channel list
//
// app.refreshChannelOrder()
// reorder the channel list by last message time

function handleNewMessage(currentChannel, messageChannel, messageContent, messageTime, sentByMe) {
  // TODO
  // when a new message sent/arrived, you need to do
  // 1. if the current channel is the new message's channel, add new message to the conversation box, scroll to bottom
  // 2. update the message on the channel list
  // 3. refresh the channel list order

  if (currentChannel === messageChannel){
    app.createMessage(messageContent, messageTime, sentByMe);
  }
    app.updateChannelList(messageChannel, messageContent, messageTime);
    app.refreshChannelOrder()
  }


